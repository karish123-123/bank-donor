<?php
session_start();
include  'connection.php';
if (isset($_POST['login'])) {
	$email =  trim($_POST['email']);
	$password =  trim($_POST['password']);
	$password = md5($password);

	$check = "SELECT * FROM `admin` WHERE `email` = '$email'  AND `password` = '$password';";
	$run_check = mysqli_query($conn, $check);
	$count = mysqli_num_rows($run_check);
	

	if($count == 1){ 
		$_SESSION['email'] = $email;
		$_SESSION['name'] = "Admin";
		?>
     <script> 
	window.location.replace("./index.php");
</script>
	 <?php } // if 
	 else{ 
	 	?>
     <script> 
	window.location.replace("./login.php?k=invalid");
</script>
	 <?php

	 }

}



else{ ?>
     <script> 
	window.location.replace("./login.php?k=no_auth");
</script>
	 <?php } ?>




