<?php
  
  $host  = "localhost";
  $user = "root";
  $pass = "";
  $db  = "lpu_blood";

  $conn = mysqli_connect($host, $user, $pass, $db);

  if(!$conn){
  	echo "Db Connection failed". mysqli_connect_error();
  }

 ?>