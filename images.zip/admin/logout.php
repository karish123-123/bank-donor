<?php
session_start();
session_unset();
session_destroy(); 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Logging Out</title>
</head>
<body>
<script> 
	window.location.replace("./login.php?k=logout");
</script>
</body>
</html><?php



