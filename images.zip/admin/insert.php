<?php 
include 'connection.php';
if (isset($_POST['register'])) {
	$Fname =  trim($_POST['Fname']);
	$Lname =  trim($_POST['Lname']);
	$name = $Fname." ".$Lname;

	$email =  trim($_POST['email']);
	$phone =  trim($_POST['phone']);
	$password =  trim($_POST['password']);
	$password = md5($password);
	$pincode = trim($_POST['pincode']);
	$blood_group =  trim($_POST['blood_group']);
	$Fname =  trim($_POST['Fname']);

	// echo "Name: $name |  password: $password  | pincode: $pincode | blood gp: $blood_group";
// check if email or phone is registered already
	$check = "SELECT * FROM `user` WHERE `email` = '$email'  OR `phone` = '$phone';";
	$run_check = mysqli_query($conn, $check);
	$count = mysqli_num_rows($run_check);


	if($count != 0){ ?>
     <script> 
	window.location.replace("./add_user.php?k=duplicate");
</script>
	 <?php } // if 
	else{
		$save = "INSERT INTO `user` ( `name`, `email`, `phone`, `password`, `blood`, `pincode`) VALUES ('$name', '$email', '$phone', '$password', '$blood_group', '$pincode');";
		$run_save = mysqli_query($conn, $save);

		if($run_save){ ?>
     <script> 
	window.location.replace("./add_user.php?k=success");
</script>
   
	 <?php }
		else{ ?>
    	 <script> 
		 window.location.replace("./add_user.php?k=error"); 
			</script>
	 <?php }
	}
}

//////////////////////////
else{ ?>
<script> 
	window.location.replace("./");
</script>
<?php }


?>