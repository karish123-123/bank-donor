<?php 
include 'connection.php';
if(isset($_GET['delete'])){
	$delete = $_GET['delete'];

	$delete = mysqli_query($conn, "DELETE FROM `user` WHERE `user`.`id` = '$delete';");
        if($delete){ ?>
            <script> 
	//window.location.replace("./view_users.php?k=success");
</script>
    <?php     }
        else{  ?>
              <script> 
	//window.location.replace("./view_users.php?k=error");
</script>
       <?php }
}


?>