
<?php 
include 'connection.php';

if (isset($_POST['update'])) {
    $name =  trim($_POST['name']);
     $id =  trim($_POST['id']);
    

    $email =  trim($_POST['email']);
    $phone =  trim($_POST['phone']);
  
    $pincode = trim($_POST['pincode']);
    

     $url =  trim($_POST['map']);

    // echo "Name: $name |  password: $password  | pincode: $pincode | blood gp: $blood_group";
// check if email or phone is registered already
    $update = "UPDATE `bank` SET `name` = '$name', `email` = '$email', `phone` =  '$phone', `location` = '$url', `pin` = '$pincode' WHERE `bank`.`id` = '$id'; ";

$run_update = mysqli_query($conn, $update);
    if($update){ ?>
     <script> 
    window.location.replace("./profile.php?k=success");
</script>
     <?php } // if 
    else{ ?>
      
     <script> 
    window.location.replace("./login.php?k=error"); 
</script>
   <?php } } ?>
  
