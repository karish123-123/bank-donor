<?php 
include 'connection.php';
if (isset($_POST['register'])) {
	$name =  trim($_POST['name']);
	
	

	$email =  trim($_POST['email']);
	$phone =  trim($_POST['phone']);
	$password =  trim($_POST['password']);
	$password = md5($password);
	$pincode = trim($_POST['pincode']);
	

	 $url =  trim($_POST['map']);

	// echo "Name: $name |  password: $password  | pincode: $pincode | blood gp: $blood_group";
// check if email or phone is registered already
	$check = "SELECT * FROM `bank` WHERE `email` = '$email'  OR `phone` = '$phone';";
	$run_check = mysqli_query($conn, $check);
	$count = mysqli_num_rows($run_check);


	if($count != 0){ ?>
     <script> 
	window.location.replace("./register.php?k=duplicate");
</script>
	 <?php } // if 
	else{
		$save = "INSERT INTO `bank` ( `name`, `email`, `phone`, `password`, `location`, `pin`) VALUES ('$name', '$email', '$phone', '$password', '$url', '$pincode');";
		$run_save = mysqli_query($conn, $save);

		if($run_save){ ?>
     <script> 
	window.location.replace("./login.php?k=success"); 
</script>
   
	 <?php }
		else{ ?>
    	 <script> 
		  window.location.replace("./register.php?k=error");  
			</script>
	 <?php }
	}
}

//////////////////////////
else{ ?>
<script> 
	window.location.replace("./login.php");
</script>
<?php }


?>